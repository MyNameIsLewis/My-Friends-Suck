﻿#pragma strict

function Start () {

}

function Update () {

}

function OnGUI() 
{
	GUI.Button(Rect(10,70,50,30), "Click Me");
}