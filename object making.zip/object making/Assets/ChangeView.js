﻿var cam1: Camera;
var cam2: Camera;
function Start () 
{
	if(cam1.enabled)
	{
	cam1.enabled = true;
	cam2.enabled = false;
	}
}

function Update () 
{
	if(Input.GetKeyDown(KeyCode.C))
	{
		changeView();
	}
}

function OnGUI() 
{
	if(GUI.Button(Rect(10,70,50,30), "Done"))
	{
		changeView();
	}
}
function changeView()
{
		cam1.enabled = !cam1.enabled;
		cam2.enabled = !cam2.enabled;
}
function TaskOnClick()
{
	cam1.enabled = !cam1.enabled;
	cam2.enabled = !cam2.enabled;
}