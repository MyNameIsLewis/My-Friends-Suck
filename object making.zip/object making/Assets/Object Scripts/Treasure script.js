﻿var cam1: Camera;
var cam2: Camera;
function Start () {

}

function Update () {

}

function OnTriggerEnter(other: Collider)
{
	Debug.Log("Something has touched me!");
	cam1.enabled = !cam1.enabled;
	cam2.enabled = !cam2.enabled;
}